create procedure mypro3(IN int_1 int, OUT int_2 int, INOUT int_3 int)
begin
		select int_1,int_2,int_3;
		
		set int_1 = 10;
		set int_2 = 100;
	  set int_3 = 1000;
		
		select int_1,int_2,int_3;
		
		select  @n1,@n2,@n3;
		
		set @n1 = 'a';
		set @n2 = 'b';
		set @n3 = 'c';
		
		select @n1,@n2,@n3;
		
end;

