create function my_fun2(age int, score int) returns int
begin
	return age + score;
end;

