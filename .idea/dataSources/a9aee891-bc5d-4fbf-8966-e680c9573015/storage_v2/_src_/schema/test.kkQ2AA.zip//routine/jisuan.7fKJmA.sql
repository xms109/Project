create function jisuan(int_num int) returns int
begin
	declare result int default 0;
	declare i int default 1;
	
	mychile:while i <= int_num do
			if i % 5 = 0 then
					set i = i + 1;
					iterate mychile;
			
			end if;
			
			set result = result + i;
			set i = i + 1;
	end while mychile;
	return result;
end;

