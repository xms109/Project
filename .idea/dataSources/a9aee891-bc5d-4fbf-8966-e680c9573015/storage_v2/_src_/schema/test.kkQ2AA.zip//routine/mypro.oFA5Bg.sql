create procedure mypro()
begin
	select * from tb_item;
end;

